#include <iostream>
#include <cstdlib>
#include <omp.h>
#include <time.h>
#include <limits.h> 

using namespace std;

int main() {
    srand((unsigned)time(NULL));
    int m, n;
    scanf("%d%d", m, n); //input the number of rows and columns for the matrix
    int ** matrix; // 
    matrix = (int**)malloc(sizeof(int*) * m);
    for (int i = 0; i < m; i++)
        matrix[i] = (int*)malloc(sizeof(int) * n);
    int max = INT_MIN; // Initialization of the maximum value
    int min = INT_MAX; // Initialization of the minimum value
    int x = 0; // The (x,) of the maximum value
    int y = 0; // The (,y) of the maximum value
    int p = 0; // The (x,) of the minimum value
    int q = 0; // The (,y) of the minimum value

    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            matrix[i][j] = rand() % 100; // The size of the value is between 0 and 99
            printf("%d ", matrix[i][j]); 
        }
        printf("\n");
    }

// Parallel part
#pragma omp parallel for collapse(2) shared(matrix) reduction(max:max) reduction(min:min)
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            if (matrix[i][j] > max) {
                max = matrix[i][j]; 
                x = i ; 
                y = j ; 
            }
            if (matrix[i][j] < min) {
                min = matrix[i][j]; 
                p = i ;
                q = j ;
            }
        }
    }

#pragma omp barrier 

#pragma omp master 
    {
        printf("min:%d (%d,%d)\n", min, p, q);
        printf("max:%d (%d,%d)\n", max, x, y);
    }

    for (int i = 0; i < m; i++)
        free(matrix[i]);
        free(matrix);
    return 0;
}